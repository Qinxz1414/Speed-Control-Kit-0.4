#include "pcb_config.h"
#include "delay.h"
#include "mxl90614.h"
int counter=20;


int main()
{unsigned int Tem1,Tem2,Tem3;
	pcb_Init();
	SMBus_Init();
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
	
	while(1)
	{
		Tem1=SMBus_ReadMemory(SA1,RAM_TOBJ1);
		display(1,1,Tem1);
		Tem2=SMBus_ReadMemory(SA2,RAM_TOBJ1);
		display(2,2,Tem2);
		Tem3=SMBus_ReadMemory(SA3,RAM_TOBJ1);
		display(3,3,Tem3);
		
		slave_num(4,4);
		write_figer(4,3,GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0));	
		write_figer(7,3,counter);	
//void GPIO_EXTILineConfig(uint8_t GPIO_PortSource, uint8_t GPIO_PinSource)
//uint8_t GPIO_ReadInputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)		
	}
}

