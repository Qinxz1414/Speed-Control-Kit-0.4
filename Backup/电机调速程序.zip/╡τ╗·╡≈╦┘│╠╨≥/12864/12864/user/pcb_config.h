#ifndef __PCB_CONFIG_H__
#define __PCB_CONFIG_H__
#include "stm32f10x.h"
#include "delay.h"
#include "12864.h"


void pcb_Init(void);


#endif

